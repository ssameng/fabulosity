HTML5 Game
=============

Previously an experiment in FrozenJS, now an experiment in Phaser.

I'm trying to find the easiest-to-learn, most robust HTML5/JavaScript game engine. Yay.
